import gym
import time
import pixelate_arena
import pybullet as p
import pybullet_data
import cv2
import os
import cv2.aruco as aruco
import numpy as np
import math


if __name__ == "__main__":
    parent_path = os.path.dirname(os.getcwd())
    os.chdir(parent_path)
    env = gym.make("pixelate_arena-v0")
    time.sleep(0.5)

    ARUCO_PARAMETERS = aruco.DetectorParameters_create()
    ARUCO_DICT = aruco.Dictionary_get(aruco.DICT_ARUCO_ORIGINAL)
    rvecs, tvecs = None, None

    img = env.camera_feed()
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)


    corners, ids, rejectedImgPoints = aruco.detectMarkers(gray, ARUCO_DICT, parameters=ARUCO_PARAMETERS)
    print('ID: {}; Corners: {}'.format(ids, corners))

    print(corners[0][0][0])
    #print(corners[1][0], corners[1][1])
    #print(corners[2][0], corners[2][1])
    #print(corners[3][0], corners[2][1])

    posfrontx1 = corners[0][0][0][0]
    posbackx4 = corners[0][0][3][0]
    posfronty1 = corners[0][0][0][1]
    posbacky4 = corners[0][0][3][1]

    delY1 = posbacky4 - posfronty1 
    delX1 = posfrontx1 - posbackx4

    angle_in_degrees1 =  np.arctan2(delY1, delX1)*(180/np.pi) 
    print(angle_in_degrees1)


    x=0

    while True:
        p.stepSimulation()
        env.move_husky(-14, 7, -14, 7)
        x = x+1

        if(x%80==0):

            for rando in range(50):
                p.stepSimulation()
                env.move_husky(0,0,0,0)

            img = env.camera_feed()
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

            corners, ids, rejectedImgPoints = aruco.detectMarkers(gray, ARUCO_DICT, parameters=ARUCO_PARAMETERS)
            #print('ID: {}; Corners: {}'.format(ids, corners))

            posfrontx1 = (corners[0][0][0][0] + corners[0][0][1][0])/2
            posbackx4 = (corners[0][0][3][0] + corners[0][0][2][0])/2
            posfronty1 =(corners[0][0][0][1] + corners[0][0][1][1])/2
            posbacky4 = (corners[0][0][3][1] + corners[0][0][2][1])/2
    
            delY1 = posbacky4 - posfronty1 
            delX1 = posfrontx1 - posbackx4

            

            angle_in_degrees1 =  np.arctan2(delY1, delX1)*(180/np.pi) 

            print("############################################")
            print(angle_in_degrees1)
            print(x)
        
        if(x>=200):
            break

        





    while True:
        p.stepSimulation()
        env.move_husky(0, 0, 0, 0)
